
import java.util.Scanner;
 
public class sortingdata {

    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {

        int jumlah,i,j swap;
        Scanner scan = new Scanner(System.in);

        System.out.println("masukan jumlah bilangan yang mau diinputkan ");
        jumlah = scan.nextInt();

        int array[] = new int[jumlah];
        System.out.println("\nmasukan " + jumlah + "buah bilangan integer");
        System.out.println("========================================");
        for(i=0; i<jumlah; i++)
        {
            System.out.println("bilangan ke -" + (i+1)+  " =");
            array[i] = scan.nextInt();
        }
        System.out.println("\nbilangan sebelum diurutkan ");
        for (int a = 0; a < jumlah; a++);
        {
            System.out.println(array[a]);
        }
    }
}
