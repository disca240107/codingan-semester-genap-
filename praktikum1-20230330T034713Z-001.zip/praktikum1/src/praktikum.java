/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class praktikum {

    public static void main(String[] args) {
        Scanner input = new Scanner (source.system.in);

        String nama = input.nextLine();
        int kelas = input.nextInt();
        String absen = input.nextLine();
        char jk = 'P';
        String value_jk;
        String alamat = "dampit ";
        int nilai = 71;
        

        System.out.println("nama siswa :" + nama);
        System.out.println("kelas siswa :" + kelas + "RPL4");
        System.out.println("absen siswa :" + absen);

        if (jk == 'L') {
            value_jk = "laki laki ";
        } else if (jk == 'P') {
            value_jk = "perempuan";
        } else {
            value_jk = "undefined";
        }

        System.out.println("jenis kelamin :" + value_jk);
        System.out.println("alamat siswa :" + alamat);
        
        if (nilai >= 75) {
            System.out.println("nilai diatas kkm " + nilai);;
        } else if (nilai <= 75) {
            System.out.println("nilai di bawah kkm " + nilai);;
        }

    }
}
