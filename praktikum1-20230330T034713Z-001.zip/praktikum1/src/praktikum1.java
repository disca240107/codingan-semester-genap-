/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class praktikum1 {
    
    int absen; 
    int nilai;
    String kelas;
    String nama;
    
    public String siswa(){
        

        return nama;   
    }
    public int absen(){
    
    return absen;
    }
    public void setabsen(int newabsen){
        absen= newabsen;
    }
    public String kelas(){
        return kelas;
    }
    public void setkelas (String newkelas){
        kelas=newkelas;
    }
   public int nilai (){
       return nilai;
   }
   public void setnilai (int newnilai){
       nilai=newnilai;
   }
    public void setNama(String newName){
        nama = newName; 
    }
    
    public int na (){
        int total;
        total = 400;
        return total;
    }
    public static void main(String[] args) {

       praktikum1 bebas = new praktikum1 ();
       bebas.setNama("Dsca");
        System.out.println("Nama Siswa : "+bebas.siswa()
        ); 
        
       bebas.setabsen(12);
        System.out.println("absen siswa :"+bebas.absen);
        
        bebas.setkelas("sepuluh rpl empat");
        System.out.println("nama kelas :"+bebas.kelas);
        
       bebas.setnilai(100);
        System.out.println("nilai siswa :"+bebas.nilai);
    }   
}

