/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class settergetter {
    public static void main(String[] args) {
        User dian = new User();
        
        dian.getUsername("dian");
        dian.getPassword("kopi java");
        
        
        System.out.println("Username  " +dian.getUsername());
        System.out.println("Password  " +dian.getPassword());
        
    }
}
