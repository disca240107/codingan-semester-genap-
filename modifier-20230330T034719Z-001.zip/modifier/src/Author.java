

/*import modifier.Person;*/

public class Author {
    

          public static void main(String[] args) {
        ujiprotected a = new ujiprotected();
        
        a.setName("i ");
        System.out.println(a.getName());
                
    }
}
