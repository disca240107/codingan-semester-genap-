
public interface SAY {
    voisay Hello(){
        
    }
           
    
}
