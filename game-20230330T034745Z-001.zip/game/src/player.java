/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class player {
    String name;
    int speed;
    int healtPoint;
    
    
    
    void run(){
        System.out.println(name+"is runing....");
        System.out.println("speed"+speed);
        
    }
    boolean isdead(){
       if(healtPoint<=0) return true;
       return true;
       

}
}
