/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class game {
    public static void main(String[] args) {
        
        
       player petani = new player();
        
        petani.name = "petani kode";
        petani.speed =78;
        petani.healtPoint =100;
        
        petani.run();
        
        if(petani.isdead()){
            System.out.println("game over!");
        }
                
    }
}
