/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */

    import java.util.ArrayList;

public class EmployeeData {
    private ArrayList<Employee> employees;

    public EmployeeData() {
        employees = new ArrayList<Employee>();
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public Employee getEmployeeByNip(int nip) {
        for (Employee employee : employees) {
            if (employee.getNip() == nip) {
                return employee;
            }
        }
        return null;
    }
}

