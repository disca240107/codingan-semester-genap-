/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class user {
 public String nama;
 public String umur;
 public String kelas;
 
 
 public user (String nama ,String umur ,String kelas){
     this.nama=nama;
     this.umur=umur;
     this.kelas=kelas;
     
 }
}
class semoconstructor{
    public static void main(String[] args) {
        
        user apa = new user ("disca","enam belas","sepuluh rpl empat");
        System.out.println("nama :"+apa.nama);
        System.out.println("umur :"+apa.umur);
        System.out.println("kelas :"+apa.kelas);
                
    }
}