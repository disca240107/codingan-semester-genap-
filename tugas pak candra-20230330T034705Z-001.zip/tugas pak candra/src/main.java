/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class main {
    public static void main(String[] args) {
        
        kubus kubus1= new kubus();
        kubus1.sisi=2;
        
        balok balok1= new balok();
        balok1.l=2;
        balok1.p=2;
        balok1.t=2;
        
         kubus1.Volume();
        
         balok1.Volume();
        
    }
    
}
