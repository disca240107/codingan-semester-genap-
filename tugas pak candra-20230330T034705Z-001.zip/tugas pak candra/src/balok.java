/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class balok extends bangunruang {
    int p,l,t;
//    @Overide
      float Volume(){
         float hasilvolume=p*l*t;
         System.out.println("volume balok adalah :"+hasilvolume);
         return hasilvolume;
        
    }
    
}
