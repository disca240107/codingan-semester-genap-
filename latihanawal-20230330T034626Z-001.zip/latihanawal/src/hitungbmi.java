
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class hitungbmi {
    public static void main(String[] args) {
        //rumus: berat(kg) / (tinggi (m)*tinggi (m))
         String nama=JOptionPane.showInputDialog("Masukan nama: ");
        JOptionPane.showMessageDialog(null, "Nama saya : "+nama);
        double berat = Double.parseDouble(JOptionPane.showInputDialog("Masukan Berat Anda: (kg)"));
        double tinggi = Double.parseDouble(JOptionPane.showInputDialog("Masukan  tinggi (m)"));
        double bmi = berat /(tinggi*tinggi);
       // JOptionPane.showMessageDialog(null, "BMI "+nama+": "+bmi);
       JOptionPane.showMessageDialog(null, "Nama Saya :"+nama+"\nBMI "+nama+": "+bmi);
    }
}
