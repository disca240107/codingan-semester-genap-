
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class luassegitiga {
    public static void main(String[] args) {
        Scanner scan=new Scanner (System.in);
        System.out.println("Masukan nilai alas: ");
        int alas = scan.nextInt();
        System.out.println("Masukan nilai tinggi: ");
        int tinggi= scan.nextInt();
        int luassegitiga = ((alas*tinggi)/2);
        System.out.println("luas segitiga: "+luassegitiga);
        
    }
}
