
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class diskusimasalah {
    public static void main(String[] args) {
        Scanner masuk=new Scanner (System.in);
        System.out.println("jumlah siswa : ");
        int n=masuk.nextInt();
        
        
        String siswa [] [] = new String [n] [3];
        
        for (int i = 0; i < n; i++) {
            
            System.out.println("");
            System.out.println("Data Siswa ke "+(i+1));
            
            
            for (int j = 0; j < 3; j++) {
               
                if (j==0)
                    System.out.println("NIS   :");
                else if (j==1)
                    System.out.println("Nama  :");
                else 
                    System.out.println("Jurusan :");
                System.out.println("");
                siswa [i][j] = masuk.next();
                
            }
            
            
        }System.out.println("data siswa dimasukan ");
        System.out.println("______________________");
        System.out.println("NIS \t\t\t NAMA \t\t\t JURUSAN\t");
        
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.println(siswa[i] [j]+ "\t\t");
                
            }System.out.println();
            
        }
    }
    
}
