
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class operator {
    public static void main(String[] args) {
        int angka1=20;
        int angka2=40;
        
        boolean pembanding = angka1 > angka2;
        boolean pembanding2=angka1 < angka2;
        boolean pembanding3=angka1 == angka2;
        boolean pembanding4=angka1 != angka2;
        
        
        System.out.println(pembanding);
        System.out.println(pembanding2);
        System.out.println(pembanding3);
        System.out.println(pembanding4);
        
       
    }
}
