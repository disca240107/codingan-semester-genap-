/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class praktikumtipedata {
    public static void main(String[] args) {
    String nama,alamat,kelas;
    int usia;
    
    nama="disca";
    alamat="malang";
    kelas="XR4";
    usia=15;
    
        System.out.println("nama :"+nama);
        System.out.println("alamat :"+alamat);
        System.out.println("kelas :"+kelas);
        System.out.println("usia :"+usia);
        System.out.println("\n");
//        System.out.println("nama "+nama+ "\nalamat" +alamat+ );
    }
}
