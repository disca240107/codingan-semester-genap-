
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class cobaarray1 {
    public static void main(String[] args) {
//      String [] nama ={"Sukhaku","Matatabi","Isobu","Son goku","Chomei","Gyuki","Kurama"};
//                    
//            System.out.println(nama[2]);
//        }
//        
             
           
          Scanner scan = new Scanner(System.in);
        System.out.print("Masukkan pilihan: ");
        int nilai = scan.nextInt();
        String[] namasiswa = new String[6];
        namasiswa[0] = "Felisa";
        namasiswa[1] = "Willy";
        namasiswa[2] = "Nata";
        namasiswa[3] = "Nia";
        namasiswa[4] = "Ajeng";
        namasiswa[5] = "Jenny";

        int pilihan = nilai;

        if (pilihan <= 5) {
            System.out.println(namasiswa[pilihan]);
        } else {
            System.out.println("data tidak ditemukan");
        }
            
//        String [] namasiswa={"disca","altav","epan1","rafii","inad"};
       
       



    }
}