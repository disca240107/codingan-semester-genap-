
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class namadialog {
    public static void main(String[] args) {
        String nama=JOptionPane.showInputDialog("Masukan nama: ");
        JOptionPane.showMessageDialog(null, "Nama saya : "+nama);
    }
}
