*/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class UKL {

    /*
    
    diketahui nilai awal 3
    beda 6
    tampilkan dari suku ke 6 hingga 10 dan jumlah deretnyaa.
    
    
    matriks 6x9
    
     */
    public static void main(String[] args) {
//        int awal = 3;
//        int beda = 6;
//        int suku = 10;
//        int u = awal;
//        int s = 0;
//
//        for (int i = 2; i <= suku; i++) {
//            u=u+beda;
//            
//
//            if (i>=6 && i<=10)
//            {
//
//                System.out.println(u + ",");
//               s=s+u; 
//            }
//        }      
//        System.out.println("");
//      
    
//        for (int i = 0; i < 6; i++) {
//            for (int j = 0; j <=8; j++) {
//                System.out.print("*");
//                
//            }System.out.println();
            
//        
//        for (int i = 0; i <10; i++) {
//            for (int j = 3; j <i; j--) {
//                System.out.print("*");
//            }
//            
//        }System.out.println();
//   for (int i = 0; i < 8; i++) {
//            for (int j = 10; j > i; j--) {
//                System.out.print("*");
//            }
//            System.out.println();
//   }
   
   /*
**
***
****
*****
****
***
****
*****
******
*****
****
***
**
*

   */
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j <=i+1; j++) {
                System.out.print("*");
                
            }
           
            System.out.println();
        }
        for (int i = 0; i < 2; i++) {
            for (int j = 4; j > i; j--) {
                System.out.print("*");
            }
            System.out.println();
        }
        for (int i = 0; i<2; i++) {
            for (int j = 0; j < i+4; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        for (int i = 0; i < 7; i++) {
            for (int j = 6; j > i; j--) {
                System.out.print("*");
            }
            System.out.println();
        }
        
    }}

