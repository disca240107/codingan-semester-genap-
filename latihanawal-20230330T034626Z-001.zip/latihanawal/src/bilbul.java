
import javax.swing.JOptionPane;


public class bilbul {
    public static void main(String[] args) {
       
        int nawal ;
        int nakhir;
        int kelipatan;
        int total=0;
        
      nawal = Integer.parseInt(JOptionPane.showInputDialog("masukan nilai awal"));
      nakhir = Integer.parseInt(JOptionPane.showInputDialog("masukan nilai akhir"));
      kelipatan = Integer.parseInt(JOptionPane.showInputDialog("masukan kelipatan"));
      
        for (int i = nawal; i <=nakhir; i+=kelipatan) {
             System.out.println(i);
            total +=i;
            
        }
        System.out.println("hasil kelipatan andalah  "+total);
        
    }
}
