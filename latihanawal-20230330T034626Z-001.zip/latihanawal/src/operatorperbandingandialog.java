

import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class operatorperbandingandialog {
    public static void main(String[] args) {
        String nama1 = JOptionPane.showInputDialog("masukan nama");
        int umur1=Integer.parseInt(JOptionPane.showInputDialog("Masukan umur "+nama1));
        String nama2 = JOptionPane.showInputDialog("masukan nama"); 
        int umur2=Integer.parseInt(JOptionPane.showInputDialog("Masukan umur "+nama2));
        
        
        boolean perbandingan= umur1 > umur2;
        
        if (perbandingan==true) {
        JOptionPane.showMessageDialog(null, nama1+" lebih tua dari"+nama2);
        
            
        }else{
                JoptionPane.showMessageDialog(null,nama1+"lebih muda dari"+nama2);
        }
    }
}
