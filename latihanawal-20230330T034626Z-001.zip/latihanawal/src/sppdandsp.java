Z
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class sppdandsp {
    public static void main(String[] args) {
       String nama = JOptionPane.showInputDialog("Masukkan Nama : ");
        String jalurMasuk = JOptionPane.showInputDialog("Masukkan Jalur Masuk : ");
        int pendapatan = Integer.parseInt(JOptionPane.showInputDialog("Masukkan Pendapatan : "));
        String KategoriPendapatan= null;
      
        if (pendapatan < 2000000){
             KategoriPendapatan = "A";
        }else if (pendapatan > 2000000 && pendapatan < 10000000){
            KategoriPendapatan = "B";
        }else if (pendapatan > 10000000){
            KategoriPendapatan = "C";
                                   
        }    
        if (jalurMasuk.equalsIgnoreCase("SBMPTN") ){
            if (KategoriPendapatan.equalsIgnoreCase("A") ){
                JOptionPane.showMessageDialog(null, "DSP: 5 juta \n SPP: 500rb");
            } else if (KategoriPendapatan.equalsIgnoreCase("B") ){
                JOptionPane.showMessageDialog(null, "DSP: 15 juta \n SPP: 1 juta");
            } else if (KategoriPendapatan.equalsIgnoreCase("C") ){
                JOptionPane.showMessageDialog(null, "DSP: 30 juta \n SPP: 2 juta");
            }
        }
        if (jalurMasuk.equalsIgnoreCase("SNMPTN") ){
            if (KategoriPendapatan.equalsIgnoreCase("A") ){
                JOptionPane.showMessageDialog(null, "DSP: 7 juta \n SPP: 500rb");
            } else if (KategoriPendapatan.equalsIgnoreCase("B") ){
                JOptionPane.showMessageDialog(null, "DSP: 17 juta \n SPP: 1 juta");
            } else if (KategoriPendapatan.equalsIgnoreCase("C") ){
                JOptionPane.showMessageDialog(null, "DSP: 35 juta \n SPP: 2 juta");
            }
        }
        if (jalurMasuk.equalsIgnoreCase("MANDIRI") ){
            if (KategoriPendapatan.equalsIgnoreCase("A") ){
                JOptionPane.showMessageDialog(null, "DSP: 10 juta \n SPP: 1 juta");
            } else if (KategoriPendapatan.equalsIgnoreCase("B") ){
                JOptionPane.showMessageDialog(null, "DSP: 25 juta \n SPP: 2 juta");
            } else if (KategoriPendapatan.equalsIgnoreCase("C") ){
                JOptionPane.showMessageDialog(null, "DSP: 50 juta \n SPP: 3 juta");
            }
        }
        
        
    
}}
        
    
   
