
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
class JOtionPane {
    public static void main(String[] args) {
//        String nawal = JOptionPane.showInputDialog("masukan nama kamu");
//        String absen = JoptionPane.showInputDialog("masukan nomor absen anda" );
//        
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j <; j++) {
                System.out.print("*");
                
            }System.out.println();
            
        }for (int i = 0; i < 5; i++) {
//            for (int j = 5; j > i; j--) {
//                System.out.print(" *");
        }
//            System.out.println();
        }
        
          
        
    }
}
