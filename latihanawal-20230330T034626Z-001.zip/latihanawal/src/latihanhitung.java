/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class latihanhitung {
    public static void main(String[] args) {
        String angka1 = "30";
        String angka2 = "30";
        int angka3 = 30;
        int angka4 = 30;
        int angka5 = 100;
        int angka6 = 125;
        System.out.println("angka1+angka2: "+angka1+angka2);
        System.out.println("angka3*angka4: "+(angka3*angka4));
        System.out.println("angka5*angka6: "+(angka5*angka6));
               
    }
  
}
