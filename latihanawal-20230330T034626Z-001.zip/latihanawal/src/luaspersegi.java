
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class luaspersegi {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Masukan nilai sisi; ");
        int sisi= scan.nextInt();
        System.out.println("Masukan nilai sisi2: ");
        int sisi2= scan.nextInt();
        int luaspersegi= ((sisi*sisi2));
        System.out.println("luas persegi: "+luaspersegi);
    }
}
