/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class latihanawal1 {
    
//        System.out.println("Nama Saya Disca");
//        System.out.println("Kelas XRPL4");
   
     public static void main(String[] args) {
        String nama = "disca anca";
        String kelas = "XRPL4";
        int usia = 15;
       String lahir = "24 Januari 2007";
        System.out.println(nama);
        System.out.println(kelas);
        System.out.println(usia);
        System.out.println(lahir);
    }  
   

}