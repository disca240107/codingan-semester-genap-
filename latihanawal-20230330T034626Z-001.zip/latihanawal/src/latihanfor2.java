/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class latihanfor2 {
    public static void main(String[] args) {
//        int nilai[]={90,80,70,100,75};
//        
//        
//        for (int n = 0; n <= 0; n++) {
//            System.out.println("90\n 80\n 70\n 100\n 75\n");
//            
//        }
//    int nilai=0;
//    do {
//            System.out.println("perulangan ke -" +nilai);
//            nilai++;
//    }
//     while (nilai <=10);
    boolean nilai=true;
    
    while (nilai = true){
            System.out.println("mengulang terus");
        }

    
    

    }
}
