
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class hotelukl {
    public static void main(String[] args) {
        
    
    Scanner input = new Scanner(System.in);
        System.out.println("Masukkan Nama");
        String nama = input.nextLine();
        System.out.println("Masukkan jenis hotel :");
        String jenishotel = input.nextLine();
        
  

        switch (jenishotel) {
            
            case "deluxe":
                System.out.println("Pilih hari :");
                System.out.println("1. Weekday\n2. Weekend\n3. Holiday");
                String inap :();
                int p1 = input.nextInt();
                switch (p1) {
                    case 1:
                        System.out.println("Berapa Malam menginap");
                        int inap =Integer.parseInt(nama)arseInt(JOptionPane.showInputDialog("berapa malam menginap"));
                      
                       
                        double t1 = p2 * 495000;
                        System.out.println("Total = " + t1);
                        break;

                    case 2:
                        System.out.println("Berapa Malam menginap");
                        int p3 = input.nextInt();
                        double t2 = p3 * 575000;

                        System.out.println("Total = " + t2);
                        break;

                    case 3:
                        System.out.println("Berapa Malam menginap");
                        int p4 = input.nextInt();
                        double t3 = p4 * 915000;
                        System.out.println("Total = " + t3);
                        break;
                        
}
                        break;

                  case "superdeluxe":
                System.out.println("Pilih hari :");
                System.out.println("1. Weekday\n2. Weekend\n3. Holiday");
                int p11 = input.nextInt();
                switch (p11) {
                    case 1:
                        System.out.println("Berapa Malam menginap");
                        int p2 = input.nextInt();
                        double t1 = p2 * 580000;
                        System.out.println("Total = " + t1);
                        break;

                    case 2:
                        System.out.println("Berapa Malam menginap");
                        int p3 = input.nextInt();
                        double t2 = p3 * 750000;

                        System.out.println("Total = " + t2);
                        break;

                    case 3:
                        System.out.println("Berapa Malam menginap");
                        int p4 = input.nextInt();
                        double t3 = p4 * 4500000;
                        System.out.println("Total = " + t3);
                        break;
}
                    break;
                   case "executive":
                System.out.println("Pilih hari :");
                System.out.println("1. Weekday\n2. Weekend\n3. Holiday");
                int p111 = input.nextInt();
                switch (p111) {
                    case 1:
                        System.out.println("Berapa Malam menginap");
                        int p2 = input.nextInt();
                        double t1 = p2 * 700000;
                        System.out.println("Total = " + t1);
                        break;

                    case 2:
                        System.out.println("Berapa Malam menginap");
                        int p3 = input.nextInt();
                        double t2 = p3 * 915000;

                        System.out.println("Total = " + t2);
                        break;

                    case 3:
                        System.out.println("Berapa Malam menginap");
                        int p4 = input.nextInt();
                        double t3 = p4 * 1800000;
                        System.out.println("Total = " + t3);
                        break;
}}}}

