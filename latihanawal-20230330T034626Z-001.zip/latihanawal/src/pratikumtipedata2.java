/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class pratikumtipedata2 {
    public static void main(String[] args) {
        String nama,kelas;
        double p,l, luas;
        
        nama="disca";
        kelas="XR4";
        p=10.0;
        l=7.5;
        luas=p*l;
        
        System.out.println("nama :"+nama);
        System.out.println("kelas :"+kelas);
        System.out.print("luas persegi panjang :"+luas);
        System.out.print("m");
                
                
    }
}
