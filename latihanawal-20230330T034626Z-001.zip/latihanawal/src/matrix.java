/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class matrix {

    public static void main(String[] args) {
        int a = 5;
        int b = 3;
        int u = a;
        int s = a;
        System.out.println("deret aritmatikanya adalah : ");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                 u = u + b;
                System.out.print(u + ",");
               
                s = s + u;

            }
            System.out.println();

        }
        s = s + u;
        System.out.println("total deret aritmnatikanya :" + s);
    }
}
