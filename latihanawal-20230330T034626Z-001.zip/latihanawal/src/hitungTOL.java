
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class hitungTOL {
    public static void main(String[] args) {
        
      String asal = JOptionPane.showInputDialog("Masukkan asal anda: ");
         String tujuan = JOptionPane.showInputDialog("Masukkan tujuan anda: ");
         String golongan = JOptionPane.showInputDialog("golongan1: sedan, jip, pick up, bus, truk kecil. \ngolongan2: truk dua gandar");
         String karcisTol=null;
        if (asal.equalsIgnoreCase("Waru") && tujuan.equalsIgnoreCase("sidoarjo") && golongan.equalsIgnoreCase("golongan1")) {
                    karcisTol = "Rp.6000";
                } else if (asal.equalsIgnoreCase("Waru") && tujuan.equalsIgnoreCase("sidoarjo") && golongan.equalsIgnoreCase("golongan2")) {
                    karcisTol = "Rp.9000";
                } 
        if (asal.equalsIgnoreCase("Waru") && tujuan.equalsIgnoreCase("porong") && golongan.equalsIgnoreCase("golongan1")) {
                    karcisTol = "Rp.9000";
                } else if (asal.equalsIgnoreCase("Waru") && tujuan.equalsIgnoreCase("porong") && golongan.equalsIgnoreCase("golongan2")) {
                    karcisTol = "Rp.14000";
                }
        if (asal.equalsIgnoreCase("Sidoarjo") && tujuan.equalsIgnoreCase("waru") && golongan.equalsIgnoreCase("golongan1")) {
                    karcisTol = "Rp.6000";
                } else if (asal.equalsIgnoreCase("sidoarjo") && tujuan.equalsIgnoreCase("waru") && golongan.equalsIgnoreCase("golongan2")) {
                    karcisTol = "Rp.9000";
                }
        if (asal.equalsIgnoreCase("Sidoarjo") && tujuan.equalsIgnoreCase("porong") && golongan.equalsIgnoreCase("golongan1")) {
                    karcisTol = "Rp.5500";
                } else if (asal.equalsIgnoreCase("sidoarjo") && tujuan.equalsIgnoreCase("porong") && golongan.equalsIgnoreCase("golongan2")) {
                    karcisTol = "Rp.8500";
                }
        if (asal.equalsIgnoreCase("porong") && tujuan.equalsIgnoreCase("sidoarjo") && golongan.equalsIgnoreCase("golongan1")) {
                    karcisTol = "Rp.5500";
                } else if (asal.equalsIgnoreCase("porong") && tujuan.equalsIgnoreCase("sidoarjo") && golongan.equalsIgnoreCase("golongan2")) {
                    karcisTol = "Rp.8500";
                }
        if (asal.equalsIgnoreCase("porong") && tujuan.equalsIgnoreCase("waru") && golongan.equalsIgnoreCase("golongan1")) {
                    karcisTol = "Rp.9000";
                } else if (asal.equalsIgnoreCase("porong") && tujuan.equalsIgnoreCase("waru") && golongan.equalsIgnoreCase("golongan2")) {
                    karcisTol = "Rp.14000";
                }
        
                    JOptionPane.showMessageDialog(null, "tarif: " +karcisTol);
       
                                   
        }    
    }

