/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class fungsi1 {
   public static void hitung(int a, int b) {
        System.out.println(a + b);
        
    }

    public static void hitung2() {
        System.out.println("nilai a dan b adalah");

    }

    public static void main(String[] args) {
        int a = 10, b = 2;
        hitung2();
        hitung(a, b);
        
    }
}
