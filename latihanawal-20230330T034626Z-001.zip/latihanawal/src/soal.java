
import java.util.Scanner;

public class soal {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Masukkan nilai anda = ");
        int nilai = input.nextInt();

        if (nilai >= 91 && nilai <= 100) {
            System.out.println("nilai A+");
            System.out.println("Predikat sangat baik");

        } else if (nilai >= 91 && nilai <= 95) {
            System.out.println("nilai A- ");
            System.out.println("predikat sangat baik");

        } else if (nilai >= 86 && nilai <= 90) {
            System.out.println("nilai B+");
            System.out.println("Predikat  baik");

        } else if (nilai >= 81 && nilai <= 85) {
            System.out.println("nilai B-");
            System.out.println("predikat  baik");

        } else if (nilai >= 76 && nilai <= 80) {
            System.out.println("nilai C+");
            System.out.println("Predikat  baik");

        } else if (nilai >= 71 && nilai <= 75) {
            System.out.println("nilai C- ");
            System.out.println("predikat sangat baik");

        } else if (nilai >= 66 && nilai <= 70) {
            System.out.println("nilai D+");
            System.out.println("Predikat sangat baik");

        } else if (nilai >= 61 && nilai <= 65) {
            System.out.println("nilai D- ");
            System.out.println("predikat sangat baik");

        } else if (nilai >= 56 && nilai <= 60) {
            System.out.println("nilai E+");
            System.out.println("Predikat kurang");

        } else if (nilai >= 51 && nilai <= 55) {
            System.out.println("nilai E- ");
            System.out.println("predikat kurang");
       
        } else if (nilai >= 0 && nilai <= 54) {
            System.out.println("nilai E+");
            System.out.println("Predikat kurang");

       

        }
    }
}
