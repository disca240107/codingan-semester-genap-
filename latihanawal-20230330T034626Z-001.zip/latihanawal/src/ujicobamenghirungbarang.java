
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class ujicobamenghirungbarang {
    public static void main(String[] args) {
        int jumlahlaptop=Integer.parseInt(JOptionPane.showInputDialog("Masukan jumlah laptop "));
        int jumlahhardisk=Integer.parseInt(JOptionPane.showInputDialog("Masukan jumlah hardsik "));
        int jumlahmouse=Integer.parseInt(JOptionPane.showInputDialog("Masukan jumlah"
                + "  mouse"));
        
        
        int hargalaptop=10000000;
        int hargahardisk=1500000;
        int hargamouse =150000;
        
        int jumlah1 = jumlahlaptop*hargalaptop;
        int jumlah2 = jumlahhardisk*hargahardisk;
        int jumlah3 = jumlahmouse*hargamouse;
        
        int jumlahasset = jumlah1+jumlah2+jumlah3;
        
          JOptionPane.showMessageDialog(null, " jumlahasset = "+jumlahasset);
        
        
         
        if(jumlahlaptop>jumlahhardisk);
            if(jumlahlaptop>jumlahmouse){
            System.out.println("yang paling banyak asset: "+jumlahlaptop);
            
            }
            else{
             System.out.println("jika tidak maka lebih banyak mouse"+jumlahmouse); 
        
    }
}}
