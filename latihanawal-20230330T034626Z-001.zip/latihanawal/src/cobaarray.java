/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class cobaarray {
    public static void main(String[] args) {
        
        String nama [] [] ={{"adi","budi","sugeng"},{"bagas","surya","mail"}};
       int nisn [] []={{1234,5678,91011},{1124,1356,4567}};
    }

    }

