/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class AeroPlan extends vehicle {
    public void walk(){
        System.out.println("aeroplan is flyng");
    }
    public static void main(String[] args) {
        AeroPlan garuda= new AeroPlan ();
        garuda.function();
        garuda.fuel();
        garuda.walk();
    }
    
}
