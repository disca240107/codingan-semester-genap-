
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class lingkaran extends bangundataer{
 
        
    
    float r;
    
    float luas(){
        float Luas =(float) (Math.PI * r * r);
        System.out.println("luas lingkaran ="+Luas);
        return Luas;
    }
    float keliling(){
        float kelling =(float)(2* Math.PI *r);
        System.out.println("keliling lingkaran ="+kelling);
        return kelling;
    }
    
}
