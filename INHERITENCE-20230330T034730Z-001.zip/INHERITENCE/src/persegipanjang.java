/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class persegipanjang extends bangundataer{
    float panjang;
    float lebar;
    
    float luas(){
        float luas=panjang*lebar;
        System.out.println("luas persegipanjang ="+luas);
        return luas;
    }
        float keliling(){
            float keling= 2*panjang+2*lebar;
            System.out.println("keliling persegipanjang ="+keling);
            return keling;
        
        
    }
}
