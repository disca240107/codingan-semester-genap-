/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class main {
    public static void main(String[] args) {
        
        bangundataer bangundataer = new bangundataer();
        
        
        persegi persegi = new persegi();
        persegi.sisi = 2;
        
       
        lingkaran lingkaran = new lingkaran();
        lingkaran.r = 22;
        
      
        persegipanjang persegiPanjang = new persegipanjang();
        persegiPanjang.panjang = 8;
        persegiPanjang.lebar = 4;
        
       
        segitiga mSegitiga = new segitiga();
        mSegitiga.alas = 12;
        mSegitiga.tinggi = 8;
        
        
         bangundataer.luas();
        bangundataer.keliling();
        
        persegi.luas();
        persegi.keliling();
        
        lingkaran.luas();
        lingkaran.keliling();
        
        persegiPanjang.luas();
        persegiPanjang.keliling();
        
        mSegitiga.luas();
        mSegitiga.keliling();
 
    }
  
}
