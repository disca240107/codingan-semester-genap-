/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Disca Anca
 */
public class persegi extends bangundataer{
    float sisi;
    float luas(){
        float luas=sisi*sisi;
        System.out.println("luas ="+luas);
        return luas;
        
    }
    float keliling(){
        float keliling=4*sisi;
        System.out.println("keliling ="+sisi);
        return keliling;
    }
    
    
}
