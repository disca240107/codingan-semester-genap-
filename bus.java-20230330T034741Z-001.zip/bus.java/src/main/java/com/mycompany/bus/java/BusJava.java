package com.mycompany.bus.java;


public class BusJava {
    public int penumpang, maxpenumpang;
    
    public void cetak(){
        System.out.println("penumpang now : "+penumpang);
        System.out.println("max penumpang : "+maxpenumpang);

   
    }
}
