package com.mycompany.bus.java;


public class ujibus {
      public static void main(String[] args) {
         
        BusJava busmini = new BusJava();
        
        busmini.penumpang =5;
        busmini.maxpenumpang = 5;
        busmini.cetak();
        
        busmini.penumpang += 2;
        busmini.cetak();
      }
    
}
