
public interface InterfaceNotification {
   abstract void sendMessag(String receiver,String content);
   void call ();
   
    
}
