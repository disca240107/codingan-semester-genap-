
public class UjiBus1 {
    public static void main(String[] args) {
        bus1 busmini = new bus1();
        
        busmini.penumpang =5;
        busmini.maxpenumpang = 5;
        busmini.cetak();
        
        busmini.penumpang += 2;
        busmini.cetak();
    }
}
